package com.sesh.jdbcsample;

public class Employee {

	String empId;
	String empName;
	
	
	public Employee() {
		super();
	}


	public Employee(String empId, String empName) {
		super();
		this.empId = empId;
		this.empName = empName;
	}

	

	public String getEmpId() {
		return empId;
	}


	public void setEmpId(String empId) {
		this.empId = empId;
	}


	public String getEmpName() {
		return empName;
	}


	public void setEmpName(String empName) {
		this.empName = empName;
	}
	

	@Override
	public String toString() {
		return "Employee Id is "+empId+" ANd his Name is "+empName;
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e1 = new Employee();
		e1.setEmpId("E001");
		e1.setEmpName("Harsha");
		System.out.println("Employee is "+e1);

	}

}
