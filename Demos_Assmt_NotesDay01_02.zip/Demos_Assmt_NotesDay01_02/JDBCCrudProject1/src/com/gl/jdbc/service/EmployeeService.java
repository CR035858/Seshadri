package com.gl.jdbc.service;

import java.util.ArrayList;

import com.gl.jdbc.dao.EmployeeDao;
import com.gl.jdbc.model.Employee;

public class EmployeeService {
	
	EmployeeDao empDao;
	public EmployeeService()
	{
		empDao = new EmployeeDao();
	}
	
	public ArrayList <Employee> getEmployeesSvc()
	{
		return empDao.getAllEmployees();
	}
	public Employee getEmployeeByIdSvc(String empId)
	{
		return empDao.getEmployeeById(empId);
	}
	public boolean insertEmployeeSvc(Employee employee)
	{
		return empDao.insertEmployee(employee);
	}
	public boolean updateEmployeeSvc(Employee employee)
	{
		return empDao.updateEmployee(employee);
	}
	public boolean deleteEmployeeByIdSvc(String empId)
	{
		return empDao.deleteEmployeeById(empId);
	}

}
