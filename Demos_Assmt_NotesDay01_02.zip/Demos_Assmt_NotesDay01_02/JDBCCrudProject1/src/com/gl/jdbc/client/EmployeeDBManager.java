package com.gl.jdbc.client;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import com.gl.jdbc.model.Employee;
import com.gl.jdbc.service.EmployeeService;

public class EmployeeDBManager {
	
	Connection conn;
	Statement stmt;
	PreparedStatement pstmt;
	String reply = "yes";
	int option;
	Scanner scan1 = new Scanner(System.in);
	ArrayList <Employee> employees;
	EmployeeService empSvc;
	
	public EmployeeDBManager()
	{
		empSvc = new EmployeeService();
	}
	public void showMenu()
	{
		while (reply.equals("Yes") || reply.equals("yes"))
		{
			System.out.println(" -------------------MAIN MENU--------------------- ");
			System.out.println(" 1. Display All Employees ");
			System.out.println(" 2. View Employee By ID ");
			System.out.println(" 3. Insert Employee Record ");
			System.out.println(" 4. Update Employee Address ");
			System.out.println(" 5. Delete Employee By Id");
			System.out.println(" 6. Exit Menu...");
			
			System.out.println("Enter Your Choice 1-6");
			option = scan1.nextInt();
			
			switch(option)
			{
				case 1:
				{
					System.out.println(" Displaying All Employee Records");
					employees = empSvc.getEmployeesSvc();
					Iterator <Employee> empIter = employees.iterator();
					while(empIter.hasNext())
					{
						Employee employee = empIter.next();
						System.out.println(employee);
					}
					break;
				}
				case 2:
				{
					System.out.println(" View Employee Record  By Id");
					System.out.println("Enter the Id of the Employee whose Record you wish to see..");
					String empId = scan1.next();
					Employee employee =  empSvc.getEmployeeByIdSvc(empId);
					System.out.println(employee);
					break;
				}
				case 3:
				{
					System.out.println(" Inserting Employee Record");
					Employee employee ;
					String empId,empName,empAddr,empPhon;
					int empSal;
					float incomeTax;
					System.out.println("Enter the Employee Id");
					empId = scan1.next();
					System.out.println("Enter the Employee Name");
					empName = scan1.next();
					System.out.println("Enter the Employee Addresss");
					empAddr = scan1.next();
					System.out.println("Enter the Employee Phone ");
					empPhon = scan1.next();
					System.out.println("Enter the Employee Salary");
					empSal = scan1.nextInt();
					System.out.println("Enter the Income Tax Liability");
					incomeTax = scan1.nextFloat();
					employee = new Employee(empId,empName,empAddr,empPhon,empSal,incomeTax);
					if(empSvc.insertEmployeeSvc(employee))
					{
						System.out.println("Employee Record Inserted successfully....");
					}
					else
					{
						System.out.println("Employee Record Insertion failed...");
					}
					break;
				}
				case 4:
				{
					System.out.println(" Updating Employee Record");
					String empId;
					String newAddress;
					Employee employeeU = new Employee();
					System.out.println("Enter the Id of the Employee whose Address you wish to ");
					empId = scan1.next();
					employeeU = empSvc.getEmployeeByIdSvc(empId);
					System.out.println("The Current Record is ");
					System.out.println(employeeU);
					System.out.println("Enter the New Address");
					newAddress = scan1.next();
					employeeU.setEmployeeAddress(newAddress);
					if(empSvc.updateEmployeeSvc(employeeU))
					{
						System.out.println("Record Updated Successfully...");
					}
					else
					{
						System.out.println("Record Updation Failed...");
					}
					break;
				}
				case 5:
				{
					System.out.println(" Deleting Employee Record  By Id");
					System.out.println("Enter the Id of the Employee whose Record you wish to delete");
					String empDelId = scan1.next();
					if(empSvc.deleteEmployeeByIdSvc(empDelId))
					{
						System.out.println("Employee Record Deleted Successfully with Id "+empDelId);
					}
					else
					{
						System.out.println("Employee Record Deletion Failed....");
					}
					break;
				}
				case 6:
				{
					System.out.println(" Exiting Application");
					System.exit(0);
					
					break;
				}
				default:
				{
					System.out.println(" Sorry Valid Options are 1 - 6");
					break;
				}
			}
			System.out.println("Do You Wish To Continue yes/no");
			reply = scan1.next();
		}
		System.out.println("You Are Out of Loop");
	}

}
