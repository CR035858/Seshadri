package com.sesh.connections;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MyConnection {
	
	String url ="jdbc:mysql://localhost:3306/Seshadri";
	String userName = "root";
	String password = "MySQL_@123456";
	Connection con;
	
	public Connection getMyConnection()
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(url, userName, password);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(SQLException sqe)
		{
			sqe.printStackTrace();
		}
		return con;
	}

}
