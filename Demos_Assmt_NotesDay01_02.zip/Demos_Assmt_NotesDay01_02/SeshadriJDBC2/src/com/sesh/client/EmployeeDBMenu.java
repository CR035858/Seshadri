package com.sesh.client;

import java.util.ArrayList;
import java.util.Scanner;

import com.sesh.model.Employee;
import com.sesh.service.EmployeeSvc;

public class EmployeeDBMenu {
	
	String reply = "Yes";
	int choice;
	Scanner scan1 = new Scanner(System.in);
	EmployeeSvc empSvc;
	public EmployeeDBMenu()
	{
		empSvc = new EmployeeSvc();
	}
	public void showEmpMenu()
	{
		
		// reply == "Yes" compares the address
		while(reply.equals("Yes") || reply.equals("YES")) // equals checks the value
		{
			System.out.println("---------------Employee Data Manipulation-------------------");
			System.out.println("1. Get All Employees ");
			System.out.println("2. Get Employee By ID ");
			System.out.println("3.Insert Employee ");
			System.out.println("4.Update Employee ");
			System.out.println("5.Delete Employee By ID");
			System.out.println("6. Exit Menu");
			System.out.println("Please enter your choice : ");
			choice = scan1.nextInt();
			
			switch(choice)
			{
				case 1:
				{
					ArrayList <Employee> employees = new ArrayList();
					employees = empSvc.getAllEmployeesSvc();
					System.out.println("The Employee Details are .....");
					//System.out.println(employees);
					for(Employee e: employees)
					{
						System.out.println(e);
					}
					break;
					
				}
				case 2:
				{
					String empId;
					System.out.println("Please enter the Id of the Employee whose Record you wish to see..");
					empId = scan1.next();
					Employee emp = empSvc.getEmployeeById(empId);
					System.out.println(emp);
					break;
				}
				case 3:
				{
					Employee employee ;
					String empId,empName,empAddress,empPhone;
					int empSalary;
					float empTax;
					
					System.out.println("Enter the Employee Details....");
					System.out.println("Enter Employee Id");
					empId = scan1.next();
					System.out.println("Enter the Employee Name ");
					empName = scan1.next();
					System.out.println("Enter the Employee Address ");
					empAddress = scan1.next();
					System.out.println("Enter the Employee Phone");
					empPhone = scan1.next();
					System.out.println("Enter the Employee Salary");
					empSalary = scan1.nextInt();
					System.out.println("Enter The Employee Income Tax Percentage ");
					empTax = scan1.nextFloat();
					
					employee = new Employee(empId,empName,empAddress,empPhone,empSalary,empTax);
					/* 2nd Method
					 * employee = new Employee()
					 * employee.setEmpId(empId);
					 * ---
					 * ---
					 */
					if(empSvc.insertEmployee(employee))
					{
						System.out.println("Employee Record Inserted Successfully....");
					}
					else
					{
						System.out.println("Sorry!!! Insertion Failed...");
					}
					break;
				}
				case 4:
				{
					break;
				}
				case 5:
				{
					break;
				}
				case 6:
				{
					break;
				}
				default:
				{
					
				}
			}
		}
				
	}
	

}
