package com.sesh.client;

public class EmpClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeDBMenu empMenu = new EmployeeDBMenu();
		empMenu.showEmpMenu();

	}

}
