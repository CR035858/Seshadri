package com.sesh.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.sesh.connections.MyConnection;
import com.sesh.model.Employee;

public class EmployeeDao {
	
	Connection con1;
	Statement stmt;
	PreparedStatement pstmt;
	ResultSet rs;
	MyConnection mycon;
	
	public EmployeeDao()
	{
		mycon = new MyConnection();
	}
	
	public ArrayList <Employee> getAllEmployees()
	{
		ArrayList <Employee> employees = new ArrayList<Employee>();
		// Invoking the Connection
		con1 = mycon.getMyConnection();
		try {
			// Creating Statement
			stmt = con1.createStatement();
			//Executing the Statement
			rs = stmt.executeQuery("select * from Employee");
			while(rs.next())
			{
				Employee emp = new Employee();
				//Populating the Employee Object from ResultSet record one by one
				emp.setEmpId(rs.getString(1));
				emp.setEmpName(rs.getString(2));
				emp.setEmpAddress(rs.getString(3));
				emp.setEmpPhone(rs.getString(4));
				emp.setEmpSalary(rs.getInt(5));
				emp.setEmpTax(rs.getFloat(6));
				//ADding the resultant employee object to the ARrayList
				employees.add(emp);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return employees;
		
	}
	
	public Employee getEmployeeById(String empId)
	{
		con1 = mycon.getMyConnection();
		Employee emp = new Employee();
		
			try {
				pstmt = con1.prepareStatement("select * from employee where empId = ? ");
				pstmt.setString(1, empId);
				rs = pstmt.executeQuery();
				rs.next();
				emp.setEmpId(rs.getString(1));
				emp.setEmpName(rs.getString(2));
				emp.setEmpAddress(rs.getString(3));
				emp.setEmpPhone(rs.getString(4));
				emp.setEmpSalary(rs.getInt(5));
				emp.setEmpTax(rs.getFloat(6));
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return emp;
	}
	
	public boolean insertEmployee(Employee employee)
	{
		boolean flag = false;
		con1 = mycon.getMyConnection();
		try {
			pstmt = con1.prepareStatement("insert into Employee values(?,?,?,?,?,?)");
			pstmt.setString(1, employee.getEmpId());
			pstmt.setString(2, employee.getEmpName());
			pstmt.setString(3, employee.getEmpAddress());
			pstmt.setString(4, employee.getEmpPhone());
			pstmt.setInt(5, employee.getEmpSalary());
			pstmt.setFloat(6, employee.getEmpTax());
			
			pstmt.execute();
			flag = true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			flag = false;
		}
		return flag;
	}
	

}
