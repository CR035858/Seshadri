package com.sesh.service;

import java.util.ArrayList;

import com.sesh.dao.EmployeeDao;
import com.sesh.model.Employee;

public class EmployeeSvc {

	EmployeeDao empDao;
	
	public EmployeeSvc()
	{
		empDao = new EmployeeDao();
	}
	
	public ArrayList <Employee> getAllEmployeesSvc()
	{
		 /* ArrayList <Employee> employees = new ArrayList();
		employees = empDao.getAllEmployees();
		return employees; */
		
		return empDao.getAllEmployees();
	}
	
	public Employee getEmployeeById(String empId)
	{
		return empDao.getEmployeeById(empId);
	}
	public boolean insertEmployee(Employee employee)
	{
		return empDao.insertEmployee(employee);
	}
		
}
