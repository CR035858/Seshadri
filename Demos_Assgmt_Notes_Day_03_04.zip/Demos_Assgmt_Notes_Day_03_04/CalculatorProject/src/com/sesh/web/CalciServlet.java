package com.sesh.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CalciServlet
 */
@WebServlet(description = "CalciServlet", urlPatterns = { "/CalciServlet" })
public class CalciServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CalciServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter pw = response.getWriter();
		pw.println("<html><body bgcolor='pink'>");
		pw.println("<center><form method='Get' action='http://localhost:8080/CalculatorProject/CalciOperation'>");
		pw.println("<h2>Welcome to Calculator Page!!!</h2>");
		pw.println("<table border='2'>");
		pw.println("<tr>");
		pw.println("<td>Enter First Number</td><td><input type='text' name='num1' /></td>");
		pw.println("</tr>");
		
		pw.println("<tr>");
		pw.println("<td>Enter Second Number</td><td><input type='text' name='num2' /></td>");
		pw.println("</tr>");
		
		pw.println("<tr>");
		pw.println("<td>ADD</td><td><input type='radio' name='cal' value='add' /></td>");
		pw.println("</tr>");
		
		pw.println("<tr>");
		pw.println("<td>MULTIPLY</td><td><input type='radio' name='cal' value='multi'/></td>");
		pw.println("</tr>");
		
		pw.println("<tr>");
		pw.println("<td>SUBTRACT</td><td><input type='radio' name='cal' value='sub' /></td>");
		pw.println("</tr>");
		
		pw.println("<tr>");
		pw.println("<td>DIVIDE</td><td><input type='radio' name='cal' value='div' /></td>");
		pw.println("</tr>");
		
		pw.println("<tr>");
		pw.println("<td><input type='submit' value='Calculate...' /></td>");
		pw.println("<td><input type='reset' value='ReSet...' /></td>");
		pw.println("</tr>");
		pw.println("</table>");
		pw.println("</form></center>");
		pw.println("</body></html>");
		
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
