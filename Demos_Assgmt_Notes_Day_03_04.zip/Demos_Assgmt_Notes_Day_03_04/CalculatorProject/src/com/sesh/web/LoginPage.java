package com.sesh.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginPage
 */
@WebServlet("/LoginPage")
public class LoginPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginPage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String userName = request.getParameter("uname");
		String password = request.getParameter("pswd");
		
		PrintWriter pw = response.getWriter();
		
		if(userName.equals("admin") && (password.equals("password")))
		{
			
			pw.println("<html><body bgcolor='yellow'>");
			
			pw.println("<center><form method='Get' action='http://localhost:8080/CalculatorProject/CalciServlet'>");
			pw.println("<center><h1>Welcome to Home Page !!! </h1></center>");
			pw.println("<center><h2>SUCCESSFUL LOGIN....</h2></center>");
			pw.println("<input type='submit' value='CalciPage...' />");
			pw.println("</center></form>");
			pw.println("</body></html>");
		}
		else
		{
			pw.println("<html><body bgcolor='red'>");
			pw.println("<center><h1>SORRY LOGIN FAILED !!! </h2></center>");
			pw.println("</body></html>");
			
		}
		
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
