package com.sesh.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CalciOperation
 */
@WebServlet("/CalciOperation")
public class CalciOperation extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CalciOperation() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter pw = response.getWriter();
		int num1 = Integer.parseInt(request.getParameter("num1"));
		int num2 = Integer.parseInt(request.getParameter("num2"));
		int result;
		String operation  = request.getParameter("cal"); 
		pw.println("<html><body bgcolor='yellow'>");
		
		if( operation.equals("add"))
		{
			result = num1 + num2;
			pw.println("<center><h2>Operation :"+operation+"</h2></center>");
			pw.println("<center><h2>Result is :"+result+"</h2></center>");
		}
		else if (operation.equals("multi"))
		{
			result = num1 * num2;
			pw.println("<center><h2>Operation :"+operation+"</h2></center>");
			pw.println("<center><h2>Result is :"+result+"</h2></center>");
		}
		else if (operation.equals("sub"))
		{
			result = num1 - num2;
			pw.println("<center><h2>Operation :"+operation+"</h2></center>");
			pw.println("<center><h2>Result is :"+result+"</h2></center>");
		}
		else if (operation.equals("div"))
		{
			result = num1 / num2;
			pw.println("<center><h2>Operation :"+operation+"</h2></center>");
			pw.println("<center><h2>Result is :"+result+"</h2></center>");
		}
		else
		{
			pw.println("<h3>SORRY WRONG OPTION </h3>");
		}
		
		pw.println("</body></html>");
		
		
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
