package com.sesh.bank;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class IntCalcServlet
 */
@WebServlet("/IntCalcServlet")
public class IntCalcServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	ServletContext ctx;
	RequestDispatcher rdisp;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public IntCalcServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		ctx = config.getServletContext();
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int principal,time,roint;
		principal = Integer.parseInt(request.getParameter("princ"));
		time = Integer.parseInt(request.getParameter("time"));
		roint = Integer.parseInt(request.getParameter("roi"));
		
		ctx.setAttribute("princi", principal);
		ctx.setAttribute("tim", time);
		ctx.setAttribute("roi", roint);
		// http://localhost:8080/AppName/ServletName
		rdisp = ctx.getRequestDispatcher("/InterestResult");
		rdisp.forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
