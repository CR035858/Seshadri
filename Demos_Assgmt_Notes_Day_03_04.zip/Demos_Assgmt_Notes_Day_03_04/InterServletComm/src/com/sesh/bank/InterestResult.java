package com.sesh.bank;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class InterestResult
 */
@WebServlet("/InterestResult")
public class InterestResult extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	ServletContext ctx;
	RequestDispatcher rdisp;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InterestResult() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		ctx = config.getServletContext();
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		double sInterest;
		int princAmt,timeYrs,rate;
		PrintWriter pw = response.getWriter();
		princAmt = Integer.parseInt(ctx.getAttribute("princi").toString());
		timeYrs = Integer.parseInt(ctx.getAttribute("tim").toString());
		rate = Integer.parseInt(ctx.getAttribute("roi").toString());
		sInterest = (princAmt * timeYrs * rate)/100;
		
		pw.println("<html><body bgcolor='yellow'>");
		pw.println("<center>");
		pw.println("<h1>Welcome to Simple Interest Result Page</h1>");
		pw.println("<h2>The Principal Amount is"+princAmt+" </h2>");
		pw.println("<h2>The Time In Yrs Amount is"+timeYrs+" </h2>");
		pw.println("<h2>The Rate Of Interst Amount is"+rate+" </h2>");
		pw.println("<h2>The Simple Interest is "+sInterest+"</h2>");
		rdisp = ctx.getRequestDispatcher("/DateGenServlet");
		// WE ARE ABOUT TO INCLUDE DATER SERVLET BELOW
		pw.println("<h3>-------------DATER SERVLET--------------</h3>");
		pw.println("<h3>We are ABout to Include Dater Servlet Below</h3>");
		rdisp.include(request, response);
		pw.println("<h3>-------------DATER SERVLET END--------------</h3>");
		pw.println("<h3>We Finished Including Dater Servlet Above</h3>");
		pw.println("<h2>This is Native Servlet</h2>");
		pw.println("</center>");
		pw.println("</body></html>");
		
		
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
